Title: MyAwesomeGame2.

Description: Simple 2D videogame using SDL.

By: Gerard Marcos Freixas
CITM Terrassa, UPC

**Latest update**
Added fullscreen and the player can only shot one bullet after another one.